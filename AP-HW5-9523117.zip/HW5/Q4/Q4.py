import math
import numpy as np
import random

def IsInCircle(x,y):#defenition of IsInCircle
    r=math.sqrt((x**2)+(y**2))
    if r <= 0.5:
        return True

def Find():
    num1 = 1
    cnt3 = 0
    while abs(((cnt3/num1)*4)-np.pi) > 0.01:#condition of problem
        num1=num1+1
        cnt3=0
        li1=[(random.uniform(-0.5,0.5),random.uniform(-0.5,0.5)) for i in range(num1)]
        for x,z in li1:
            if IsInCircle(x, z):
                cnt3 = cnt3 + 1
    print(' ')
    print("minimum random number : ",num1)
    print((cnt3 / num1) * 4)
    print("diffrence between our pi estimation and numpy.pi : ",abs(((cnt3/num1)*4)-np.pi))#show estimation of pi
    return num1

recall= int(input('Plese enter number of recalling the Find() function : ')) # number of recalling the Find()
i=0
x=0
while i < recall :
    x=Find()
    i=i+1
    x=x+x
print(' ')
print("average of at least number of 0.01 estmation : ",'{:.5f}'.format(x/recall))



