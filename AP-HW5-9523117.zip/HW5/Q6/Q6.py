import numpy as np
import math
import subprocess
import pandas as pd
import matplotlib.pyplot as plt
from time import time as epockTime

class CGaussSolver:
    def __init__(self, func, a, b, n):
        self.function = func
        self.m_A = float(a)
        self.m_B = float(b)
        self.m_N = n
        self.m_Result = 0
    def legendre(self, m_N, x):
        if m_N == 0:
            return 1
        elif m_N == 1:
            return x
        else:
            return ((2.0 * m_N - 1) / m_N) * x * self.legendre(m_N - 1, x) - ((1.0 * m_N - 1) / m_N) * self.legendre(m_N - 2, x)

    def dlegendre(self, m_N, x):
        dleggendr = (1.0 * m_N / (x * x - 1.0)) * ((x * self.legendre(m_N, x)) - self.legendre(m_N - 1.0, x))
        return dleggendr
    def legendreZeroes(self, m_N, k):
        k = k +1
        pi = 3.141592
        xold1 = np.cos(pi * (k - 1 / 4.0) / (m_N + 1 / 2.0))
        iteration = 1
        while True:
            if iteration != 1:
                xold1 = xnew1
            xnew1 = xold1 - self.legendre(m_N, xold1) / self.dlegendre(m_N, xold1)
            iteration += 1
            if (1 + abs(xnew1 - xold1)) <= 1.0:
                break
        return xnew1

    def weight(self, m_N, x):
        weightI = 2 / ((1.0 - x**2.0) * self.dlegendre(m_N, x)**2)
        return weightI

    def exec(self):
        iteration = 1
        iteration = iteration + 1
        integral = 0.0
        for i in range(self.m_N):
            integral = integral + \
                       self.function(self.legendreZeroes(self.m_N, i)) * self.weight(self.m_N,self.legendreZeroes(self.m_N, i))
        self.m_Result = ((self.m_B - self.m_A) / 2.0) * integral

    def getResult(self):
        return self.m_Result

def aFunction(x):
    xN = (0.5 * x) + 0.5
    return ((xN ** 3) / (xN + 1)) * np.cos(xN ** 2)

li2=[]
"""__main__ """
for x in range(3,10):
    start=epockTime()
    n = int(float(x))
    a, b = 0, 1
    aSolver = CGaussSolver(lambda y: aFunction(y), a, b, n)
    aSolver.exec()
    print("the resule is : ", aSolver.getResult())
    end=epockTime()
    li2.append(end-start)
li3=[]
for y in range(3,10):
    start1=epockTime()
    subprocess.call(["ConsoleApplication7.exe",str(y)])
    end1=epockTime()
    li3.append(start1-end1)


fig, ax = plt.subplots()
fig.patch.set_visible(False)
ax.axis('off')
ax.axis('tight')
collabel=("n","3", "4", "5","6","7","8","9")
li4=["cpp"]
for i in range(len(li2)):
    li4.append(li2[i])
print(li4)
li5=["py"]
for i in range(len(li3)):
    li5.append(li3[i])
li6=[li4,li5]
clust_data = li6
ax.table(cellText=clust_data,colLabels=collabel,loc='center')
plt.savefig("result.pdf")
plt.show()






