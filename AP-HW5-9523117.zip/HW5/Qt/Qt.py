import sys
from PyQt5 import QtCore
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication ,QMainWindow
import os
import sqlite3
import requests
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from PyQt5.QtWidgets import QLabel, QMainWindow, QApplication, QWidget, QVBoxLayout
from PyQt5.QtGui import QPixmap
import sys
from time import sleep
import matplotlib
from qtconsole.qt import QtCore
matplotlib.use('Qt5Agg')
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout
from PyQt5 import uic
from PyQt5.QtGui import QPixmap



connection = sqlite3.connect('PYQTMAP.db')
c = connection.cursor()
c.execute('CREATE TABLE IF NOT EXISTS users(id integer primary key  autoincrement,name text,\
    phone integer ,username text,password text)')
c.execute('CREATE TABLE IF NOT EXISTS locations (id integer primary key autoincrement,\
     user_id integer,lat integer,lon integer,ctime current_timestamp )')



Form = uic.loadUiType(os.path.join(os.getcwd(),'gui2.ui'))[0]
Form1 = uic.loadUiType(os.path.join(os.getcwd(),'gui.ui'))[0]
Form2 = uic.loadUiType(os.path.join(os.getcwd(),'gui3.ui'))[0]
class Log(Form1,QMainWindow):
    def __init__(self):
        Form.__init__(self)
        QMainWindow.__init__(self)
        self.setupUi(self)
        self.register_2.clicked.connect(self.showReg)
        self.login.clicked.connect(self.showMap)

    def showMap(self):
        username1 = self.username.text()
        password1 = self.password.text()
        print(password1, username1)
        x = c.execute( "SELECT name FROM users where username =?",(username1,))
        self.hide()
        self.map=Map()
        self.map.lineEdit1.setText('Hello'+' '+f'{x.fetchall()[0][0]}'+'  welcome')
        self.map.show()


    def showReg(self):
        self.hide()
        self.reg=Reg()
        self.reg.show()


class Reg(Form,QMainWindow):
    def __init__(self):
        Form.__init__(self)
        QMainWindow.__init__(self)
        self.setupUi(self)
        self.register_3.clicked.connect(self.Reginfo)
        self.register_3.clicked.connect(self.showMap2)

    def Reginfo(self):
        name = self.name.text()
        phone = self.phone.text()
        username = self.username.text()
        password = self.password.text()
        print(name," ",phone," ",username," ",password)
        stmt="INSERT INTO users(name,phone,username,password)values(?,?,?,?)"
        args = (name, phone, username, password)
        connection.execute(stmt, args)
        connection.commit()
        c.close()
        connection.close()

    def showMap2(self):
        self.hide()
        self.map1 = Map()
        self.map1.lineEdit1.setText('Hello ' + f'{self.name.text()}'+' welcome')
        self.map1.show()



class Map(Form2,QMainWindow):
    def __init__(self):
        Form.__init__(self)
        QMainWindow.__init__(self)
        self.setupUi(self)
        self.MAP.clicked.connect(self.map)
        sleep(2)
        self.MAP.clicked.connect(self.setPic)
        #self.MAP.clicked.connect(self.shmap)

    def map(self):
        print("Hello")
        self.my_lat = self.LAT.text()
        self.my_lon= self.LON.text()

        self.response = requests.get('https://map.ir/static', params={'width': 512, 'height': 512, 'zoom_level': 4,
                                                                 'markers': 'color:origin|label:Map|' + str(
                                                                     self.my_lon) + ',' + str(self.my_lat)}, headers={
            'x-api-key': 'WsLdHK46I5Wfr5xgI0ynjjyiw9Fyhydu'})
        img =self.response.content
        with open('loc.png', 'wb') as f:
            f.write(img)

    def setPic(self):
        pimap = QPixmap('loc.png')
        self.label_5.setPixmap(pimap)


app=QApplication(sys.argv)
w=Log()
w.show()
sys.exit(app.exec_())

