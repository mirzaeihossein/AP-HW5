def total(a,b,*numbers,**phonebook):
    print('first :',a)
    print('second : ',b)
#print single items in numbers
    for num in numbers:
        print('single items : ',num)
#print each items of dictionary
    for name,num in phonebook.items():
        print(f'name is {name} and phone_num is {num}')

print(total(10,20,1,2,3,4,5,hossein=123,jack=345,sara=1234568))