import os
from pathlib import Path

def create_dir(name,address):
    os.chdir(address)#change directory
    if not os.path.exists(name):#check exist
        os.mkdir(name)#make directory

def create_file(name,address):
    os.chdir(address)#change directory
    if not os.path.exists(name):#check exist
        Path(name).touch()#make a file

def delete(name,address):
    os.chdir(address)#change directory
    if os.path.exists(name):#check exist
        os.remove(name)#remove

def find(name,address):
    os.chdir(address)#change directory
    for root, dirs, files in os.walk(".", topdown=False):#check in all
        for name1 in files:
            if name1==name:
                print(os.path.join(root, name1))#join to path
        for name1 in dirs:
            if name1 == name:
                print(os.path.join(root, name))


create_dir('AP','D:\\')
create_file('ap.txt','D:\AP')
delete('ap.txt','D:\AP')
find('matlab','D:\\')

